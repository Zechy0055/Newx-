import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // GitHub OAuth routes
  app.get('/api/github/auth', (req, res) => {
    const clientId = process.env.GITHUB_CLIENT_ID;
    if (!clientId) {
      return res.status(500).json({ message: 'GitHub OAuth not configured' });
    }
    
    const scope = 'repo,read:user';
    const redirectUri = `${req.protocol}://${req.get('host')}/api/github/callback`;
    const githubAuthUrl = `https://github.com/login/oauth/authorize?client_id=${clientId}&scope=${scope}&redirect_uri=${encodeURIComponent(redirectUri)}`;
    
    res.redirect(githubAuthUrl);
  });

  app.get('/api/github/callback', async (req, res) => {
    const { code } = req.query;
    const clientId = process.env.GITHUB_CLIENT_ID;
    const clientSecret = process.env.GITHUB_CLIENT_SECRET;
    
    if (!code || !clientId || !clientSecret) {
      return res.redirect('/?error=github_auth_failed');
    }

    try {
      // Exchange code for access token
      const tokenResponse = await fetch('https://github.com/login/oauth/access_token', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          client_id: clientId,
          client_secret: clientSecret,
          code: code,
        }),
      });

      const tokenData = await tokenResponse.json();
      
      if (tokenData.access_token) {
        // Store token in session
        (req.session as any).githubToken = tokenData.access_token;
        res.redirect('/dashboard');
      } else {
        res.redirect('/?error=github_auth_failed');
      }
    } catch (error) {
      console.error('GitHub OAuth error:', error);
      res.redirect('/?error=github_auth_failed');
    }
  });

  app.get('/api/github/user', async (req, res) => {
    const token = (req.session as any)?.githubToken;
    
    if (!token) {
      return res.status(401).json({ message: 'GitHub not authenticated' });
    }

    try {
      const response = await fetch('https://api.github.com/user', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/vnd.github.v3+json',
        },
      });

      if (response.ok) {
        const user = await response.json();
        res.json(user);
      } else {
        res.status(401).json({ message: 'Invalid GitHub token' });
      }
    } catch (error) {
      console.error('GitHub API error:', error);
      res.status(500).json({ message: 'GitHub API error' });
    }
  });

  app.get('/api/github/repositories', async (req, res) => {
    const token = (req.session as any)?.githubToken;
    
    if (!token) {
      return res.status(401).json({ message: 'GitHub not authenticated' });
    }

    try {
      const response = await fetch('https://api.github.com/user/repos?sort=updated&per_page=100', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/vnd.github.v3+json',
        },
      });

      if (response.ok) {
        const repos = await response.json();
        res.json(repos);
      } else {
        res.status(401).json({ message: 'Failed to fetch repositories' });
      }
    } catch (error) {
      console.error('GitHub API error:', error);
      res.status(500).json({ message: 'GitHub API error' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
