interface AgentBubbleProps {
  text: string;
}

export default function AgentBubble({ text }: AgentBubbleProps) {
  return (
    <div className="flex items-start space-x-2 mb-2 animate-fade-in">
      <img 
        src="https://ui-avatars.com/api/?name=Agent&background=444&color=fff" 
        alt="Agent" 
        className="w-8 h-8 rounded-full" 
      />
      <div className="bg-gray-800 px-4 py-3 rounded-xl text-sm max-w-[80%]">
        {text}
      </div>
    </div>
  );
}
