import { useState, useEffect } from "react";
import { Menu, X, Plus, Search, Settings, Github } from "lucide-react";
import { useLocation } from "wouter";
import RepositoryModal from "./RepositoryModal";

interface Repository {
  id: number;
  name: string;
  full_name: string;
  description: string | null;
  private: boolean;
  stargazers_count: number;
  language: string | null;
  updated_at: string;
  default_branch: string;
}

export default function NavBar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [location, setLocation] = useLocation();
  const [isRepoModalOpen, setIsRepoModalOpen] = useState(false);
  const [connectedRepo, setConnectedRepo] = useState<Repository | null>(() => {
    const saved = localStorage.getItem('connected-repository');
    return saved ? JSON.parse(saved) : null;
  });

  // Lock body scroll when menu is open
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    // Cleanup on unmount
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMenuOpen]);

  // Save connected repository to localStorage
  useEffect(() => {
    if (connectedRepo) {
      localStorage.setItem('connected-repository', JSON.stringify(connectedRepo));
    } else {
      localStorage.removeItem('connected-repository');
    }
  }, [connectedRepo]);

  const recentTasks = [
    { id: 1, title: "Fix authentication bug", time: "2 hours ago" },
    { id: 2, title: "Add dark mode toggle", time: "Yesterday" },
    { id: 3, title: "Optimize database queries", time: "3 days ago" },
  ];

  const handleNewChat = () => {
    const event = new CustomEvent('newChat');
    window.dispatchEvent(event);
    setIsMenuOpen(false);
  };

  const handleConnectRepository = () => {
    setIsRepoModalOpen(true);
    setIsMenuOpen(false);
  };

  const handleSelectRepository = (repo: Repository) => {
    setConnectedRepo(repo);
  };

  const handleDisconnectRepository = () => {
    setConnectedRepo(null);
  };

  return (
    <>
      <nav className="bg-black border-b border-gray-800">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          {/* Left side - Hamburger and Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-xl transition-colors"
            >
              <Menu size={20} />
            </button>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-white rounded-md flex items-center justify-center">
                  <div className="w-3.5 h-3.5 bg-black rounded-sm"></div>
                </div>
              </div>
              {connectedRepo && (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-gray-800 rounded-lg border border-gray-700">
                  <Github size={14} className="text-gray-400" />
                  <span className="text-sm text-white font-medium">{connectedRepo.name}</span>
                  <button
                    onClick={handleDisconnectRepository}
                    className="text-gray-400 hover:text-white ml-1"
                    title="Disconnect repository"
                  >
                    <X size={12} />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Right side - New Chat Button */}
          <div className="flex items-center gap-3">
            <button
              onClick={handleNewChat}
              className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-xl transition-colors flex items-center gap-2"
            >
              <Plus size={18} />
              <span className="hidden sm:inline text-sm font-medium">New Chat</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Dropdown Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 bg-gray-950/95 backdrop-blur-sm z-50 overflow-hidden">
          <div className="flex flex-col h-full bg-black">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-800 bg-gray-900/50">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                  <div className="w-5 h-5 bg-black rounded-sm"></div>
                </div>
              </div>
              <button
                onClick={() => setIsMenuOpen(false)}
                className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-xl transition-colors"
              >
                <X size={24} />
              </button>
            </div>

            {/* Search */}
            <div className="p-6">
              <div className="relative">
                <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search tasks and repositories..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-gray-900 border border-gray-700 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 focus:bg-gray-800 transition-all"
                />
              </div>
            </div>

            {/* Menu Options */}
            <div className="px-6 space-y-3">
              <button
                onClick={handleConnectRepository}
                className="w-full flex items-center gap-3 px-4 py-3 text-left rounded-xl text-green-400 hover:bg-green-900/30 border border-green-500/30 hover:border-green-400/50 transition-all"
              >
                <Github size={18} />
                <span className="font-medium">Connect Repository</span>
              </button>
              
              <button
                onClick={() => {
                  setLocation("/settings");
                  setIsMenuOpen(false);
                }}
                className="w-full flex items-center gap-3 px-4 py-3 text-left rounded-xl text-gray-300 hover:bg-gray-800/50 border border-gray-700/30 hover:border-gray-600/50 transition-all"
              >
                <Settings size={18} />
                <span className="font-medium">Settings</span>
              </button>
            </div>

            {/* Recent Tasks */}
            <div className="px-6 py-6 flex-1 overflow-y-auto">
              <h3 className="text-gray-400 text-sm font-medium mb-4 uppercase tracking-wide">Recent Tasks</h3>
              <div className="space-y-2">
                {recentTasks.map((task) => (
                  <button
                    key={task.id}
                    onClick={() => setIsMenuOpen(false)}
                    className="w-full text-left p-3 rounded-xl hover:bg-gray-800/50 transition-colors border border-transparent hover:border-gray-700/30"
                  >
                    <div className="text-white font-medium text-sm">{task.title}</div>
                    <div className="text-gray-500 text-xs mt-1">{task.time}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="p-6 border-t border-gray-800 bg-gray-900/30">
              <div className="text-xs text-gray-500">
                AI-Powered Development Assistant
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Repository Connection Modal */}
      <RepositoryModal
        isOpen={isRepoModalOpen}
        onClose={() => setIsRepoModalOpen(false)}
        onSelectRepository={handleSelectRepository}
      />
    </>
  );
}