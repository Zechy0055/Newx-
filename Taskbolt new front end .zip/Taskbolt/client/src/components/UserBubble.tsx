import { useAuth } from "@/hooks/useAuth";

interface UserBubbleProps {
  text: string;
}

export default function UserBubble({ text }: UserBubbleProps) {
  const { user } = useAuth();

  const getInitials = (firstName?: string | null, lastName?: string | null) => {
    if (firstName || lastName) {
      return `${firstName?.[0] || ''}${lastName?.[0] || ''}`.toUpperCase();
    }
    return 'U';
  };

  const getUserAvatarUrl = () => {
    if (user?.profileImageUrl) {
      return user.profileImageUrl;
    }
    const initials = getInitials(user?.firstName, user?.lastName);
    return `https://ui-avatars.com/api/?name=${initials}&background=0D8ABC&color=fff`;
  };

  return (
    <div className="flex items-end justify-end space-x-2 mb-2 animate-fade-in">
      <div className="bg-blue-600 px-4 py-3 rounded-xl text-sm max-w-[80%]">
        {text}
      </div>
      <img 
        src={getUserAvatarUrl()} 
        alt="User" 
        className="w-8 h-8 rounded-full object-cover" 
      />
    </div>
  );
}
