export default function TypingIndicator() {
  return (
    <div className="flex items-start space-x-2 mb-2 animate-fade-in">
      <img 
        src="https://ui-avatars.com/api/?name=Agent&background=444&color=fff" 
        alt="Agent" 
        className="w-8 h-8 rounded-full" 
      />
      <div className="bg-gray-800 px-4 py-2 rounded-xl text-sm flex items-center gap-1">
        <span className="inline-block w-2 h-2 bg-gray-400 rounded-full animate-bounce"></span>
        <span className="inline-block w-2 h-2 bg-gray-400 rounded-full animate-bounce-delay-150"></span>
        <span className="inline-block w-2 h-2 bg-gray-400 rounded-full animate-bounce-delay-300"></span>
        <span className="ml-2 text-gray-400 text-xs">Agent is typing…</span>
      </div>
    </div>
  );
}
