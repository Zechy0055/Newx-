import { useAuth } from "@/hooks/useAuth";
import { Search, Settings } from "lucide-react";
import { Link } from "wouter";

export default function TopBar() {
  const { user } = useAuth();

  const getInitials = (firstName?: string | null, lastName?: string | null) => {
    if (firstName || lastName) {
      return `${firstName?.[0] || ''}${lastName?.[0] || ''}`.toUpperCase();
    }
    return 'U';
  };

  const getUserAvatarUrl = () => {
    if (user?.profileImageUrl) {
      return user.profileImageUrl;
    }
    const initials = getInitials(user?.firstName, user?.lastName);
    return `https://ui-avatars.com/api/?name=${initials}&background=0D8ABC&color=fff`;
  };

  return (
    <div 
      className="w-full max-w-2xl flex items-center gap-4 px-4 py-3 border-b border-gray-800 bg-black bg-opacity-60 fixed top-0 left-1/2 -translate-x-1/2 z-10" 
      style={{backdropFilter: "blur(12px)"}}
    >
      {/* Logo */}
      <div className="flex items-center gap-2">
        <div className="h-8 w-8 rounded-full bg-[#272b31] flex items-center justify-center">
          <span className="text-sm font-bold text-white">T</span>
        </div>
        <span className="font-bold text-lg tracking-tight">Taskbolt AI</span>
      </div>
      
      {/* Search Bar with Settings */}
      <div className="flex-1 flex items-center gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search conversations..."
            className="w-full bg-gray-800/50 border border-gray-700/50 rounded-xl pl-10 pr-4 py-2 text-sm text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50 transition-all"
          />
        </div>
        
        {/* Settings Icon */}
        <Link href="/settings">
          <button className="p-2 rounded-xl bg-gray-800/50 border border-gray-700/50 text-gray-400 hover:text-white hover:bg-gray-700/50 transition-all">
            <Settings className="h-5 w-5" />
          </button>
        </Link>
      </div>
    </div>
  );
}
