import { useState, useEffect } from "react";
import { X, Github, Search, Folder, Star, GitBranch } from "lucide-react";

interface Repository {
  id: number;
  name: string;
  full_name: string;
  description: string | null;
  private: boolean;
  stargazers_count: number;
  language: string | null;
  updated_at: string;
  default_branch: string;
}

interface RepositoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRepository: (repo: Repository) => void;
}

export default function RepositoryModal({ isOpen, onClose, onSelectRepository }: RepositoryModalProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [repositories, setRepositories] = useState<Repository[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [error, setError] = useState<string | null>(null);

  const filteredRepos = repositories.filter(repo => 
    repo.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    repo.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const checkGitHubAuth = async () => {
    try {
      const response = await fetch('/api/github/user');
      if (response.ok) {
        setIsAuthenticated(true);
        fetchRepositories();
      } else {
        setIsAuthenticated(false);
      }
    } catch (err) {
      setIsAuthenticated(false);
    }
  };

  const fetchRepositories = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/github/repositories');
      if (response.ok) {
        const repos = await response.json();
        setRepositories(repos);
      } else {
        const errorData = await response.json();
        setError(errorData.message || 'Failed to fetch repositories');
      }
    } catch (err) {
      setError('Network error while fetching repositories');
    } finally {
      setLoading(false);
    }
  };

  const handleGitHubLogin = () => {
    window.location.href = '/api/github/auth';
  };

  const handleSelectRepo = (repo: Repository) => {
    onSelectRepository(repo);
    onClose();
  };

  useEffect(() => {
    if (isOpen) {
      checkGitHubAuth();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-2xl border border-gray-700 w-full max-w-2xl max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <Github size={24} className="text-white" />
            <h2 className="text-xl font-semibold text-white">Connect Repository</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden">
          {!isAuthenticated ? (
            /* GitHub Authentication */
            <div className="p-6 text-center">
              <Github size={64} className="text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-white mb-2">Connect your GitHub account</h3>
              <p className="text-gray-400 mb-6">
                Sign in with GitHub to access your repositories and start working with your code.
              </p>
              <button
                onClick={handleGitHubLogin}
                className="bg-white text-black px-6 py-3 rounded-lg font-medium hover:bg-gray-200 transition-colors flex items-center gap-2 mx-auto"
              >
                <Github size={20} />
                Sign in with GitHub
              </button>
            </div>
          ) : (
            /* Repository Selection */
            <div className="flex flex-col h-full">
              {/* Search */}
              <div className="p-6 border-b border-gray-700">
                <div className="relative">
                  <Search size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search repositories..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-gray-800 border border-gray-600 rounded-lg pl-10 pr-4 py-3 text-white placeholder-gray-400 focus:outline-none focus:border-gray-500"
                  />
                </div>
              </div>

              {/* Repository List */}
              <div className="flex-1 overflow-y-auto p-6">
                {loading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin w-8 h-8 border-2 border-gray-600 border-t-white rounded-full mx-auto mb-4"></div>
                    <p className="text-gray-400">Loading repositories...</p>
                  </div>
                ) : error ? (
                  <div className="text-center py-8">
                    <p className="text-red-400 mb-4">{error}</p>
                    <button
                      onClick={fetchRepositories}
                      className="text-blue-400 hover:text-blue-300 underline"
                    >
                      Try again
                    </button>
                  </div>
                ) : filteredRepos.length === 0 ? (
                  <div className="text-center py-8">
                    <Folder size={48} className="text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-400">
                      {searchQuery ? 'No repositories match your search' : 'No repositories found'}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {filteredRepos.map((repo) => (
                      <button
                        key={repo.id}
                        onClick={() => handleSelectRepo(repo)}
                        className="w-full text-left p-4 bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-gray-600 rounded-lg transition-all group"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h3 className="font-medium text-white group-hover:text-blue-400 transition-colors">
                                {repo.name}
                              </h3>
                              {repo.private && (
                                <span className="text-xs bg-yellow-500/20 text-yellow-400 px-2 py-0.5 rounded">
                                  Private
                                </span>
                              )}
                            </div>
                            {repo.description && (
                              <p className="text-sm text-gray-400 mb-2 line-clamp-2">{repo.description}</p>
                            )}
                            <div className="flex items-center gap-4 text-xs text-gray-500">
                              {repo.language && (
                                <span className="flex items-center gap-1">
                                  <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                                  {repo.language}
                                </span>
                              )}
                              <span className="flex items-center gap-1">
                                <Star size={12} />
                                {repo.stargazers_count}
                              </span>
                              <span className="flex items-center gap-1">
                                <GitBranch size={12} />
                                {repo.default_branch}
                              </span>
                            </div>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}