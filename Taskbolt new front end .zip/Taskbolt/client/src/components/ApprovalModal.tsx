interface ApprovalModalProps {
  onApprove: () => void;
  onDecline: () => void;
}

export default function ApprovalModal({ onApprove, onDecline }: ApprovalModalProps) {
  return (
    <div className="fixed inset-0 z-20 flex items-end justify-center pb-8">
      <div className="bg-[#151a22] border border-gray-800 shadow-2xl px-6 py-5 rounded-2xl w-full max-w-xs mx-auto text-center animate-fade-in">
        <div className="mb-3 text-white font-semibold text-lg">
          Approve this action?
        </div>
        <div className="mb-6 text-gray-300 text-sm">
          The agent is about to delete your last Instagram post.
        </div>
        <div className="flex justify-center gap-4">
          <button 
            onClick={onDecline} 
            className="px-6 py-2 rounded-lg bg-gray-800 text-gray-200 font-semibold hover:bg-gray-700 transition"
          >
            No Thanks
          </button>
          <button 
            onClick={onApprove} 
            className="px-6 py-2 rounded-lg bg-blue-600 text-white font-semibold hover:bg-blue-500 transition"
          >
            Approve
          </button>
        </div>
      </div>
    </div>
  );
}
