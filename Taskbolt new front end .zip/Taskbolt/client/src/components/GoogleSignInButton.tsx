export default function GoogleSignInButton() {
  return (
    <button 
      className="bg-white text-black font-semibold flex items-center gap-2 px-5 py-2 rounded-lg shadow hover:bg-gray-100 transition" 
      onClick={() => window.location.href = '/api/login'}
    >
      <img 
        src="https://upload.wikimedia.org/wikipedia/commons/5/53/Google_%22G%22_Logo.svg" 
        alt="G" 
        className="w-5 h-5" 
      />
      Sign in with Google
    </button>
  );
}
