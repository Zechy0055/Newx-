import { Github, FolderOpen } from "lucide-react";

interface UploadDropdownProps {
  isOpen: boolean;
  connectedRepo: any;
  onConnectRepository: () => void;
  onUploadFiles: () => void;
}

export default function UploadDropdown({ 
  isOpen, 
  connectedRepo, 
  onConnectRepository, 
  onUploadFiles 
}: UploadDropdownProps) {
  if (!isOpen) return null;

  return (
    <div className="absolute bottom-full left-0 mb-2 bg-gray-800 border border-gray-600 rounded-lg shadow-lg min-w-48 z-10">
      <div className="p-2">
        <button
          onClick={onConnectRepository}
          className="w-full text-left px-3 py-2 text-sm text-white hover:bg-gray-700 rounded-lg flex items-center gap-3 transition-colors"
        >
          <Github size={16} className="text-blue-400" />
          <div>
            <div className="font-medium">Connect Repository</div>
            <div className="text-xs text-gray-400">Link your GitHub repo</div>
          </div>
        </button>
        
        {connectedRepo && (
          <div className="px-3 py-2 text-xs text-gray-400 border-t border-gray-700 mt-2">
            Connected: <span className="text-white">{connectedRepo.name}</span>
          </div>
        )}
        
        <div className="border-t border-gray-700 mt-2 pt-2">
          <button
            onClick={onUploadFiles}
            className="w-full text-left px-3 py-2 text-sm text-white hover:bg-gray-700 rounded-lg flex items-center gap-3 transition-colors"
          >
            <FolderOpen size={16} className="text-green-400" />
            <div>
              <div className="font-medium">Upload Files</div>
              <div className="text-xs text-gray-400">Images, videos, documents</div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}