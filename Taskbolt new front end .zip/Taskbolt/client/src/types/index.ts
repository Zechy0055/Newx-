export interface Message {
  sender: "user" | "agent";
  text: string;
  file?: {
    name: string;
    type: string;
    url: string;
  };
  codePreview?: {
    filename: string;
    language: string;
    code: string;
    changes: string;
  };
  fileAnalysis?: {
    files: Array<{ name: string; type: string; lines: number; issues?: string[] }>;
    summary: string;
  };
  taskPlan?: {
    title: string;
    steps: Array<{ step: string; files: string[]; estimated: string }>;
    dependencies: string[];
  };
}

export interface Repository {
  id: number;
  name: string;
  full_name: string;
  description: string | null;
  private: boolean;
  stargazers_count: number;
  language: string | null;
  updated_at: string;
  default_branch: string;
}

export interface ChatState {
  messages: Message[];
  input: string;
  selectedFile: File | null;
  isTyping: boolean;
  showWelcome: boolean;
  currentStatus: string | null;
  showApproval: boolean;
  taskAccepted: boolean;
  currentTaskId: string | null;
  showSuggestions: boolean;
  expandedCodeId: string | null;
  showUploadDropdown: boolean;
  isRepoModalOpen: boolean;
}