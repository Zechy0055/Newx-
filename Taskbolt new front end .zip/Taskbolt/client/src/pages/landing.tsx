import { useLocation } from "wouter";
import { useState, useEffect } from "react";
import { MessageSquare, Users, Code, Globe, Star, Shield, Zap } from "lucide-react";

export default function Landing() {
  const [, navigate] = useLocation();
  const [input, setInput] = useState("");
  const [currentExample, setCurrentExample] = useState(0);

  const examples = [
    "Fix this login bug in our React app",
    "Add user search to the dashboard",
    "Optimize database queries for faster loading", 
    "Deploy hotfix to production",
    "Add TypeScript types to legacy code"
  ];

  const powerMoves = [
    {
      userPrompt: "Fix authentication bug in our React app",
      steps: ["Analyzing GitHub issue", "Locating bug in codebase", "Generating patch", "✅ Fix ready for review"]
    },
    {
      userPrompt: "Add user search feature to dashboard",
      steps: ["Understanding requirements", "Building search component", "Writing tests", "✅ Feature implemented"]
    },
    {
      userPrompt: "Optimize slow database queries",
      steps: ["Profiling query performance", "Identifying bottlenecks", "Refactoring queries", "✅ 80% faster response"]
    },
    {
      userPrompt: "Deploy critical security patch",
      steps: ["Validating fix", "Running test suite", "Deploying to staging", "✅ Live in production"]
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentExample((prev) => (prev + 1) % examples.length);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-black text-white relative w-full scroll-container mobile-optimized">
      {/* Clean Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-black"></div>
        <div className="absolute inset-0 opacity-20">
          <div className="neural-grid"></div>
        </div>
        <div className="floating-particles"></div>
      </div>

      {/* Navigation */}
      <nav className="relative z-50 flex w-full max-w-7xl mx-auto items-center justify-between px-6 py-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
            <div className="w-6 h-6 bg-black rounded-sm"></div>
          </div>
          <span className="text-2xl font-bold tracking-tight text-white">Taskbolt</span>
        </div>
        <button 
          onClick={() => navigate("/dashboard")}
          className="bg-white text-black font-semibold px-8 py-3 rounded-lg hover:bg-gray-100 transition-all duration-200 shadow-lg"
        >
          Try Now
        </button>
      </nav>

      {/* Hero Section */}
      <section className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 sm:px-6 lg:px-8 text-center">
        <div className="max-w-6xl mx-auto w-full">
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-black mb-8 md:mb-12 leading-[0.9] tracking-tight">
            <span className="block text-white mb-3 md:mb-4 animate-fade-in-up">Chat with AI to</span>
            <span className="block text-blue-500 mb-3 md:mb-4 animate-fade-in-up animation-delay-200">Fix, Add Features, Edit and Improve Your Code</span>
          </h1>
          
          <p className="text-lg sm:text-xl md:text-2xl text-gray-300 mb-12 md:mb-16 max-w-4xl mx-auto leading-relaxed font-light animate-fade-in-up animation-delay-400 px-4">
            Just describe what you need—Taskbolt understands your repo and makes the changes for you.
          </p>

          {/* Browser Mockup */}
          <div className="glassmorphic-browser mx-auto mb-12 max-w-4xl">
            <div className="browser-header">
              <div className="browser-dots">
                <div className="dot red"></div>
                <div className="dot yellow"></div>
                <div className="dot green"></div>
              </div>
              <div className="browser-url">taskbolt.ai/dashboard</div>
            </div>
            <div className="browser-content">
              <div className="chat-interface">
                <div className="user-message">
                  <div className="message-bubble user">
                    {examples[currentExample]}
                  </div>
                </div>
                <div className="agent-response">
                  <div className="agent-avatar">
                    <div className="agent-pulse"></div>
                    🤖
                  </div>
                  <div className="message-bubble agent">
                    <div className="typing-indicator">
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                    Agent is working...
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* CTA Section */}
          <div className="flex flex-col items-center gap-6 mb-16">
            <button 
              onClick={() => navigate("/dashboard")}
              className="bg-white text-black font-bold text-xl px-12 py-5 rounded-lg hover:bg-gray-100 transition-all duration-200 shadow-2xl"
            >
              Try with Your Repository
            </button>
            <p className="text-gray-500 text-sm">
              Connect GitHub • Understands your project • Reasons before making changes
            </p>
          </div>

          {/* Input Field */}
          <div className="max-w-2xl mx-auto mb-8">
            <div className="glassmorphic-input">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Try: Fix the login bug in my React app"
                className="w-full bg-transparent text-white placeholder-gray-500 text-lg px-6 py-4 outline-none"
              />
            </div>
          </div>

          <p className="text-gray-500 text-sm max-w-2xl mx-auto">
            Taskbolt understands your codebase, reasons before acting, and only touches what matters. Built for open source and private projects.
          </p>
        </div>
      </section>

      {/* How It Works */}
      <section className="relative z-10 py-16 md:py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
            <div className="glassmorphic-card text-center">
              <div className="step-number">1</div>
              <h3 className="text-2xl font-bold mb-4">Connect Repository</h3>
              <div className="chat-example">
                <div className="example-bubble">Link your GitHub repo</div>
              </div>
            </div>
            
            <div className="glassmorphic-card text-center">
              <div className="step-number">2</div>
              <h3 className="text-2xl font-bold mb-4">Chat & Request</h3>
              <div className="agent-steps">
                <div className="step">
                  <div className="step-icon step-completed">✓</div>
                  "Fix the authentication bug"
                </div>
                <div className="step">
                  <div className="step-icon step-completed">✓</div>
                  "Add payment integration"
                </div>
                <div className="step">
                  <div className="step-icon step-completed">✓</div>
                  "Deploy to production"
                </div>
              </div>
            </div>
            
            <div className="glassmorphic-card text-center">
              <div className="step-number">3</div>
              <h3 className="text-2xl font-bold mb-4">Taskbolt Delivers</h3>
              <div className="approval-buttons">
                <button className="approve-btn">✓ Approve</button>
                <button className="decline-btn">✗ No Thanks</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Power Moves */}
      <section className="relative z-10 py-32 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-5xl md:text-7xl font-black mb-4 text-white">
            Watch It
          </h2>
          <h2 className="text-5xl md:text-7xl font-black mb-16 text-gray-400">
            Work Live
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {powerMoves.map((move, index) => (
              <div key={index} className="power-move-card">
                <div className="user-prompt">"{move.userPrompt}"</div>
                <div className="agent-steps-list">
                  {move.steps.map((step, stepIndex) => (
                    <div key={stepIndex} className="step-item">
                      {step}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Teams Love It */}
      <section className="relative z-10 py-32 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-5xl md:text-7xl font-black mb-4 text-white">
            The Intelligence
          </h2>
          <h2 className="text-5xl md:text-7xl font-black mb-16 text-gray-400">
            Behind the Magic
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mt-16">
            <div className="feature-card">
              <MessageSquare className="w-8 h-8 text-blue-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">Deep Code Analysis</h3>
              <p className="text-gray-400">Maps your entire project structure, dependencies, and architectural patterns</p>
            </div>
            
            <div className="feature-card">
              <Shield className="w-8 h-8 text-green-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">Multi-Agent Architecture</h3>
              <p className="text-gray-400">Specialized agents work simultaneously across different components</p>
            </div>
            
            <div className="feature-card">
              <Globe className="w-8 h-8 text-purple-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">Intelligent Problem Solving</h3>
              <p className="text-gray-400">Reasons through complex issues before making precise changes</p>
            </div>
            
            <div className="feature-card">
              <Code className="w-8 h-8 text-yellow-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">Universal Language Support</h3>
              <p className="text-gray-400">Works seamlessly with any programming language or framework</p>
            </div>
            
            <div className="feature-card">
              <Zap className="w-8 h-8 text-blue-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">Conversational Interface</h3>
              <p className="text-gray-400">Communicate complex requirements in simple, natural language</p>
            </div>
            
            <div className="feature-card">
              <Shield className="w-8 h-8 text-cyan-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">Production-Ready Output</h3>
              <p className="text-gray-400">Every change is tested, validated, and deployment-ready</p>
            </div>
          </div>
        </div>
      </section>

      {/* Developer Stories */}
      <section className="relative z-10 py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-black text-center mb-16 text-white">Real Impact Stories</h2>
          <div className="grid md:grid-cols-2 gap-12">
            <div className="testimonial-card">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold">S</div>
                <div>
                  <div className="text-white font-semibold">Sarah Chen</div>
                  <div className="text-gray-400 text-sm">Solo Founder, TechFlow</div>
                </div>
              </div>
              <p className="text-lg mb-4 text-gray-300">"My authentication system was completely broken across 15 files. Taskbolt mapped the entire flow, identified the session handling issue, and fixed it in 8 minutes. I would have spent days debugging this."</p>
              <div className="text-blue-400 text-sm">Fixed critical auth bug • 15 files updated • Production ready</div>
            </div>
            
            <div className="testimonial-card">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-cyan-500 rounded-full flex items-center justify-center text-white font-bold">M</div>
                <div>
                  <div className="text-white font-semibold">Marcus Rivera</div>
                  <div className="text-gray-400 text-sm">Lead Developer, StartupCo</div>
                </div>
              </div>
              <p className="text-lg mb-4 text-gray-300">"Asked it to add Stripe payments to my Next.js app. It understood my component structure, created the payment flow, handled webhooks, and even added TypeScript types. Absolutely incredible."</p>
              <div className="text-green-400 text-sm">Added payment system • 12 components created • Type-safe</div>
            </div>
          </div>
        </div>
      </section>

      {/* Futuristic AI Agent Showcase */}
      <section className="relative z-10 py-32 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-7xl font-black mb-6 text-white">
              Meet Your
            </h2>
            <h2 className="text-5xl md:text-7xl font-black mb-8 text-blue-400">
              AI Agent
            </h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Always online. Always learning. Always ready to transform your code.
            </p>
          </div>

          {/* 3D Agent Mockup */}
          <div className="relative max-w-4xl mx-auto">
            {/* Main Agent Container */}
            <div className="agent-container">
              {/* Neural Network Background */}
              <div className="neural-network">
                <div className="neural-line neural-line-1"></div>
                <div className="neural-line neural-line-2"></div>
                <div className="neural-line neural-line-3"></div>
                <div className="neural-line neural-line-4"></div>
                <div className="neural-node neural-node-1"></div>
                <div className="neural-node neural-node-2"></div>
                <div className="neural-node neural-node-3"></div>
                <div className="neural-node neural-node-4"></div>
                <div className="neural-node neural-node-5"></div>
              </div>

              {/* Central AI Core */}
              <div className="ai-core">
                <div className="core-ring core-ring-1"></div>
                <div className="core-ring core-ring-2"></div>
                <div className="core-ring core-ring-3"></div>
                <div className="core-center">
                  <div className="core-pulse"></div>
                  <div className="core-brain">🧠</div>
                </div>
              </div>

              {/* Floating Code Blocks */}
              <div className="floating-code floating-code-1">
                <div className="code-block">
                  <div className="code-header">
                    <div className="code-dots">
                      <span></span><span></span><span></span>
                    </div>
                    <span className="code-title">auth.js</span>
                  </div>
                  <div className="code-content">
                    <div className="code-line">function validateUser() {"{"}</div>
                    <div className="code-line code-highlight">✓ Fixed session bug</div>
                    <div className="code-line">{"}"}</div>
                  </div>
                </div>
              </div>

              <div className="floating-code floating-code-2">
                <div className="code-block">
                  <div className="code-header">
                    <div className="code-dots">
                      <span></span><span></span><span></span>
                    </div>
                    <span className="code-title">api.ts</span>
                  </div>
                  <div className="code-content">
                    <div className="code-line">export const paymentAPI = &#123;</div>
                    <div className="code-line code-highlight">✓ Added Stripe integration</div>
                    <div className="code-line">&#125;</div>
                  </div>
                </div>
              </div>

              <div className="floating-code floating-code-3">
                <div className="code-block">
                  <div className="code-header">
                    <div className="code-dots">
                      <span></span><span></span><span></span>
                    </div>
                    <span className="code-title">deploy.yml</span>
                  </div>
                  <div className="code-content">
                    <div className="code-line">name: Production Deploy</div>
                    <div className="code-line code-highlight">✓ Ready for deployment</div>
                    <div className="code-line">runs-on: ubuntu-latest</div>
                  </div>
                </div>
              </div>

              {/* Status Indicators */}
              <div className="status-indicator status-1">
                <div className="status-dot status-active"></div>
                <span>Analyzing codebase</span>
              </div>
              <div className="status-indicator status-2">
                <div className="status-dot status-success"></div>
                <span>15 files processed</span>
              </div>
              <div className="status-indicator status-3">
                <div className="status-dot status-working"></div>
                <span>Deploying changes</span>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="text-center mt-16">
            <button 
              onClick={() => navigate("/auth")}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold text-xl px-12 py-6 rounded-2xl transition-all duration-300 transform hover:scale-105 shadow-2xl"
            >
              Activate Your Agent
            </button>
            <p className="text-gray-400 text-sm mt-4">
              Connect GitHub • Start coding with AI • Deploy instantly
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="relative z-10 py-24 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-black text-center mb-16">FAQ</h2>
          
          <div className="space-y-6">
            <div className="faq-item">
              <h3 className="text-xl font-bold mb-2">How does it understand my codebase?</h3>
              <p className="text-gray-400">Taskbolt reads all your files, understands dependencies, imports, and how different parts connect. It builds a complete map of your project structure.</p>
            </div>
            
            <div className="faq-item">
              <h3 className="text-xl font-bold mb-2">What if I have a large project with 100+ files?</h3>
              <p className="text-gray-400">Perfect. Taskbolt deploys multiple agents that work simultaneously across different files. The more complex your project, the more it shines.</p>
            </div>
            
            <div className="faq-item">
              <h3 className="text-xl font-bold mb-2">Do I need to know how to code?</h3>
              <p className="text-gray-400">Nope. Just chat with it like you're talking to a developer friend. "Fix the login", "add dark mode", "make it mobile responsive" - it understands.</p>
            </div>
            
            <div className="faq-item">
              <h3 className="text-xl font-bold mb-2">What about my private repositories?</h3>
              <p className="text-gray-400">Your code stays private. We only access what you explicitly share, and all processing happens securely. You maintain full control.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-gray-800/50 py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main CTA Section */}
          <div className="mb-12">
            <h3 className="text-3xl font-black text-white mb-4">Stop wasting time on bug fixes and reviews</h3>
            <p className="text-gray-400 text-lg mb-8">Let Taskbolt handle your backlog, so your team can focus on what matters.</p>
            <button 
              onClick={() => navigate("/auth")}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-200 transform hover:scale-105"
            >
              Get Started Today
            </button>
          </div>
          
          {/* Simple Links */}
          <div className="flex justify-center items-center gap-8 mb-8 text-gray-400">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Support</a>
          </div>
          
          {/* Copyright */}
          <div className="text-gray-500 text-sm">
            © 2025 Taskbolt AI — Automation, Reborn.
          </div>
        </div>
      </footer>
    </div>
  );
}
