import { useState, useEffect } from "react";
import NavBar from "@/components/NavBar";
import { User, Mail, Shield, Trash2, LogOut, AlertTriangle } from "lucide-react";

export default function Settings() {
  const [userEmail, setUserEmail] = useState("");
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState("");

  useEffect(() => {
    // Fetch user email from auth endpoint
    fetch('/api/auth/user')
      .then(res => res.json())
      .then(data => {
        if (data?.email) {
          setUserEmail(data.email);
        }
      })
      .catch(() => {
        setUserEmail("user@example.com"); // Fallback for demo
      });
  }, []);

  const handleSignOut = () => {
    window.location.href = '/api/logout';
  };

  const handleDeleteAccount = () => {
    if (deleteConfirmText === "DELETE") {
      // Handle account deletion
      alert("Account deletion functionality would be implemented here");
      setShowDeleteConfirm(false);
      setDeleteConfirmText("");
    }
  };

  return (
    <div className="min-h-screen bg-black flex flex-col overflow-hidden">
      <div className="fixed top-0 left-0 right-0 z-50">
        <NavBar />
      </div>
      
      <div className="flex-1 w-full max-w-2xl mx-auto flex flex-col pt-20 px-4 sm:px-6">
        <div className="py-6">
          <h1 className="text-2xl font-bold text-white mb-2">Settings</h1>
          <p className="text-gray-400">Manage your account preferences and security</p>
        </div>

        <div className="space-y-6">
          {/* Account Information */}
          <div className="bg-gray-900/50 border border-gray-700 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-blue-900/30 rounded-lg">
                <User size={20} className="text-blue-400" />
              </div>
              <h2 className="text-xl font-semibold text-white">Account Information</h2>
            </div>
            
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Email Address
                </label>
                <div className="flex items-center gap-3 p-3 bg-gray-800/50 border border-gray-600 rounded-lg">
                  <Mail size={16} className="text-gray-400" />
                  <span className="text-white">{userEmail}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Security Actions */}
          <div className="bg-gray-900/50 border border-gray-700 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-orange-900/30 rounded-lg">
                <Shield size={20} className="text-orange-400" />
              </div>
              <h2 className="text-xl font-semibold text-white">Security</h2>
            </div>
            
            <div className="space-y-4">
              <button
                onClick={handleSignOut}
                className="w-full flex items-center gap-3 p-4 bg-gray-800/50 hover:bg-gray-700/50 border border-gray-600 hover:border-gray-500 rounded-lg transition-colors text-left"
              >
                <LogOut size={18} className="text-gray-400" />
                <div>
                  <div className="text-white font-medium">Sign Out</div>
                  <div className="text-gray-400 text-sm">Sign out of your account</div>
                </div>
              </button>
            </div>
          </div>

          {/* Danger Zone */}
          <div className="bg-red-900/10 border border-red-500/30 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-red-900/30 rounded-lg">
                <AlertTriangle size={20} className="text-red-400" />
              </div>
              <h2 className="text-xl font-semibold text-red-400">Danger Zone</h2>
            </div>
            
            <div className="space-y-4">
              <div className="p-4 bg-red-900/20 border border-red-500/30 rounded-lg">
                <div className="flex items-start gap-3">
                  <Trash2 size={18} className="text-red-400 mt-1" />
                  <div className="flex-1">
                    <div className="text-white font-medium mb-1">Delete Account</div>
                    <div className="text-gray-400 text-sm mb-4">
                      Permanently delete your account and all associated data. This action cannot be undone.
                    </div>
                    <button
                      onClick={() => setShowDeleteConfirm(true)}
                      className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-medium rounded-lg transition-colors"
                    >
                      Delete Account
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowDeleteConfirm(false)} />
          <div className="relative bg-gray-900 border border-red-500/30 rounded-xl p-6 w-full max-w-md">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-red-900/30 rounded-lg">
                <AlertTriangle size={20} className="text-red-400" />
              </div>
              <h3 className="text-lg font-semibold text-white">Delete Account</h3>
            </div>
            
            <p className="text-gray-300 mb-4">
              This will permanently delete your account and all associated data. This action cannot be undone.
            </p>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-400 mb-2">
                Type "DELETE" to confirm:
              </label>
              <input
                type="text"
                value={deleteConfirmText}
                onChange={(e) => setDeleteConfirmText(e.target.value)}
                className="w-full p-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:outline-none focus:border-red-500"
                placeholder="DELETE"
              />
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false);
                  setDeleteConfirmText("");
                }}
                className="flex-1 px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white font-medium rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteAccount}
                disabled={deleteConfirmText !== "DELETE"}
                className="flex-1 px-4 py-2 bg-red-600 hover:bg-red-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-medium rounded-lg transition-colors"
              >
                Delete Account
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}