import { useState, useRef, useEffect } from "react";
import NavBar from "@/components/NavBar";
import RepositoryModal from "@/components/RepositoryModal";
import UploadDropdown from "@/components/UploadDropdown";
import { useRepository } from "@/hooks/useRepository";
import { useChat } from "@/hooks/useChat";
import { useFileUpload } from "@/hooks/useFileUpload";
import { useInputManager } from "@/hooks/useInputManager";
import { Paperclip, Image, Video, Send, Code, Maximize2 } from "lucide-react";
import { Message } from "@/types";

export default function Dashboard() {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [isRepoModalOpen, setIsRepoModalOpen] = useState(false);
  
  // Custom hooks for modular state management
  const { connectedRepo, connectRepository } = useRepository();
  const {
    messages,
    input,
    isTyping,
    currentStatus,
    showApproval,
    showSuggestions,
    expandedCodeId,
    setExpandedCodeId,
    addMessage,
    clearChat,
    startCodingWorkflow,
    setShowApproval
  } = useChat();
  
  const {
    selectedFile,
    showUploadDropdown,
    fileInputRef,
    handleFileSelect,
    removeFile,
    triggerFileInput,
    toggleUploadDropdown,
    setShowUploadDropdown
  } = useFileUpload();
  
  const {
    inputRef,
    handleInput,
    handleKeyDown,
    clearInput
  } = useInputManager();

  // Save messages to localStorage
  useEffect(() => {
    localStorage.setItem('taskbolt-messages', JSON.stringify(messages));
  }, [messages]);



  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, currentStatus]);

  // Handle new chat event
  useEffect(() => {
    const handleNewChat = () => {
      setMessages([]);
      setInput("");
      setSelectedFile(null);
      setShowSuggestions(false);
      setCurrentStatus(null);
      setShowApproval(false);
      setCurrentTaskId(null);
      setTaskAccepted(false);
      setShowUploadDropdown(false);
    };

    window.addEventListener('newChat', handleNewChat);
    return () => window.removeEventListener('newChat', handleNewChat);
  }, []);

  // Close upload dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (showUploadDropdown) {
        setShowUploadDropdown(false);
      }
    };

    if (showUploadDropdown) {
      document.addEventListener('click', handleClickOutside);
      return () => document.removeEventListener('click', handleClickOutside);
    }
  }, [showUploadDropdown]);

  // Welcome message effect
  useEffect(() => {
    if (showWelcome) {
      const timer = setTimeout(() => {
        setMessages([{ sender: "agent", text: "👋 Hey, I'm your AI coding agent. Connect your repository and I'll help you fix bugs, add features, and improve your code!" }]);
        setShowWelcome(false);
        
        // Show suggestions after a few seconds
        setTimeout(() => {
          setShowSuggestions(true);
        }, 3000);
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [showWelcome]);

  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    setIsTyping(true);
    
    // Auto-resize textarea
    e.target.style.height = 'auto';
    e.target.style.height = Math.min(e.target.scrollHeight, 160) + 'px';
    
    // Hide typing indicator after user stops typing
    setTimeout(() => setIsTyping(false), 1000);
  };

  const handleSend = () => {
    if (input.trim() || selectedFile) {
      const newMessage: Message = { 
        sender: "user", 
        text: input.trim() || "Shared a file",
        file: selectedFile ? {
          name: selectedFile.name,
          type: selectedFile.type,
          url: URL.createObjectURL(selectedFile)
        } : undefined
      };
      setMessages(m => [...m, newMessage]);
      setInput("");
      setSelectedFile(null);
      setTaskAccepted(false);
      setShowSuggestions(false);
      setShowApproval(false);
      setCurrentTaskId(null);
      setIsTyping(false);
      
      // Start coding agent workflow
      startCodingWorkflow(newMessage.text);
      
      if (inputRef.current) {
        inputRef.current.style.height = 'auto';
      }
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const startCodingWorkflow = (userRequest: string) => {
    const taskId = Date.now().toString();
    setCurrentTaskId(taskId);
    
    // Phase 1: File Analysis
    setTimeout(() => {
      setCurrentStatus("Analyzing Repository");
    }, 500);
    
    setTimeout(() => {
      setCurrentStatus("Reading Files");
    }, 2000);
    
    setTimeout(() => {
      setCurrentStatus("Planning Task");
    }, 4000);
    
    setTimeout(() => {
      setCurrentStatus(null);
      
      // Add analysis results
      const analysisMessage: Message = {
        sender: "agent",
        text: "I've analyzed your repository structure. Here's what I found:",
        fileAnalysis: {
          files: [
            { name: "client/src/pages/dashboard.tsx", type: "React Component", lines: 650, issues: ["Complex component", "Could use refactoring"] },
            { name: "client/src/components/NavBar.tsx", type: "React Component", lines: 158 },
            { name: "server/routes.ts", type: "API Routes", lines: 45 },
            { name: "shared/schema.ts", type: "Database Schema", lines: 32 }
          ],
          summary: "Found React frontend with Express backend. Repository has good structure with client/server separation."
        }
      };
      
      setMessages(m => [...m, analysisMessage]);
      
      // Phase 2: Task Planning
      setTimeout(() => {
        const planMessage: Message = {
          sender: "agent",
          text: "Based on your request, here's my implementation plan:",
          taskPlan: {
            title: userRequest.includes("dark mode") ? "Implement Dark Mode" : 
                   userRequest.includes("responsive") ? "Make Mobile Responsive" :
                   userRequest.includes("bug") ? "Fix Authentication Bug" : "Code Enhancement",
            steps: [
              { step: "Update theme context", files: ["client/src/lib/ThemeContext.tsx"], estimated: "2 min" },
              { step: "Modify main components", files: ["client/src/App.tsx", "client/src/pages/dashboard.tsx"], estimated: "3 min" },
              { step: "Update CSS variables", files: ["client/src/index.css"], estimated: "1 min" }
            ],
            dependencies: ["React", "Tailwind CSS"]
          }
        };
        
        setMessages(m => [...m, planMessage]);
        
        // Phase 3: Show code preview
        setTimeout(() => {
          showCodePreview();
        }, 2000);
      }, 1500);
    }, 6000);
  };

  const showCodePreview = () => {
    const codeMessage: Message = {
      sender: "agent",
      text: "Here's the code I'll implement. Review and approve to proceed:",
      codePreview: {
        filename: "client/src/lib/ThemeContext.tsx",
        language: "typescript",
        code: `import { createContext, useContext, useState, useEffect } from 'react';

type Theme = 'light' | 'dark';

interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>('light');

  useEffect(() => {
    const stored = localStorage.getItem('theme') as Theme;
    if (stored) {
      setTheme(stored);
      document.documentElement.classList.toggle('dark', stored === 'dark');
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
};`,
        changes: "Creates new theme context with localStorage persistence and dark mode toggle functionality"
      }
    };
    
    setMessages(m => [...m, codeMessage]);
    setShowApproval(true);
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const removeFile = () => {
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSelectRepository = (repo: any) => {
    connectRepository(repo);
  };

  const handleConnectRepository = () => {
    setIsRepoModalOpen(true);
    setShowUploadDropdown(false);
  };

  const toggleUploadDropdown = () => {
    setShowUploadDropdown(!showUploadDropdown);
  };

  return (
    <div className="min-h-screen bg-black flex flex-col overflow-hidden">
      {/* Fixed Navigation with auto-hide behavior */}
      <div className={`fixed top-0 left-0 right-0 z-50 transition-transform duration-300 ease-in-out ${isTyping ? '-translate-y-full' : 'translate-y-0'}`}>
        <NavBar />
      </div>
      
      <div className={`flex-1 w-full max-w-6xl mx-auto flex flex-col pb-20 px-2 sm:px-4 lg:px-6 overflow-y-auto transition-all duration-300 ${isTyping ? 'pt-4' : 'pt-20'}`}>
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex w-full mb-3 sm:mb-4 ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`px-3 sm:px-4 py-2 sm:py-3 rounded-xl sm:rounded-2xl break-words ${
              msg.sender === "user" 
                ? "bg-gray-800 text-white max-w-[75%] sm:max-w-md lg:max-w-lg" 
                : "text-white max-w-[85%] sm:max-w-2xl lg:max-w-4xl"
            }`}>
              <div className="text-sm sm:text-base leading-relaxed break-words overflow-wrap-anywhere">
                {msg.sender === "agent" && (
                  <div>
                    {/* File Analysis Display */}
                    {msg.fileAnalysis && (
                      <div className="mb-4">
                        <div className="flex items-center gap-2 text-blue-400 text-xs uppercase tracking-wide font-medium mb-3">
                          <div className="w-1.5 h-1.5 bg-blue-400 rounded-full"></div>
                          Repository Analysis
                        </div>
                        <div className="p-4 bg-gray-900/50 border border-gray-700 rounded-xl">
                          <p className="text-gray-300 text-sm mb-3">{msg.fileAnalysis.summary}</p>
                          <div className="space-y-2">
                            {msg.fileAnalysis.files.map((file, i) => (
                              <div key={i} className="flex items-center justify-between p-2 bg-gray-800/50 rounded-lg">
                                <div>
                                  <div className="text-white text-sm font-medium">{file.name}</div>
                                  <div className="text-gray-400 text-xs">{file.type} • {file.lines} lines</div>
                                  {file.issues && (
                                    <div className="text-yellow-400 text-xs mt-1">
                                      {file.issues.join(", ")}
                                    </div>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Task Plan Display */}
                    {msg.taskPlan && (
                      <div className="mb-4">
                        <div className="flex items-center gap-2 text-green-400 text-xs uppercase tracking-wide font-medium mb-3">
                          <div className="w-1.5 h-1.5 bg-green-400 rounded-full"></div>
                          Implementation Plan
                        </div>
                        <div className="p-4 bg-gray-900/50 border border-gray-700 rounded-xl">
                          <h4 className="text-white font-medium mb-3">{msg.taskPlan.title}</h4>
                          <div className="space-y-3">
                            {msg.taskPlan.steps.map((step, i) => (
                              <div key={i} className="flex items-start gap-3">
                                <div className="w-6 h-6 bg-green-500/20 text-green-400 rounded-full flex items-center justify-center text-xs font-bold mt-0.5">
                                  {i + 1}
                                </div>
                                <div className="flex-1">
                                  <div className="text-white text-sm">{step.step}</div>
                                  <div className="text-gray-400 text-xs mt-1">
                                    Files: {step.files.join(", ")} • Est. {step.estimated}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                          {msg.taskPlan.dependencies.length > 0 && (
                            <div className="mt-3 pt-3 border-t border-gray-700">
                              <div className="text-gray-400 text-xs">
                                Dependencies: {msg.taskPlan.dependencies.join(", ")}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Code Preview Display */}
                    {msg.codePreview && (
                      <div className="mb-4">
                        <div className="flex items-center gap-2 text-purple-400 text-xs uppercase tracking-wide font-medium mb-3">
                          <div className="w-1.5 h-1.5 bg-purple-400 rounded-full"></div>
                          Code Preview
                        </div>
                        <div className="p-4 bg-gray-900/50 border border-gray-700 rounded-xl">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                              <Code size={16} className="text-purple-400" />
                              <div className="text-white font-medium text-sm">{msg.codePreview.filename}</div>
                            </div>
                            <div className="flex items-center gap-2">
                              <div className="text-gray-400 text-xs bg-gray-800 px-2 py-1 rounded">
                                {msg.codePreview.language}
                              </div>
                              <button
                                onClick={() => setExpandedCodeId(expandedCodeId === `code-${idx}` ? null : `code-${idx}`)}
                                className="p-1.5 text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors"
                                title="View code"
                              >
                                <Maximize2 size={14} />
                              </button>
                            </div>
                          </div>
                          
                          {/* Collapsible code preview section with border indicator */}
                          <div 
                            className={`border-2 border-dashed border-gray-600 rounded-lg p-3 mb-3 cursor-pointer transition-all ${expandedCodeId === `code-${idx}` ? 'border-purple-500 bg-gray-950' : 'hover:border-gray-500'}`}
                            onClick={() => setExpandedCodeId(expandedCodeId === `code-${idx}` ? null : `code-${idx}`)}>
                            {expandedCodeId === `code-${idx}` ? (
                              <div className="overflow-x-auto">
                                <pre className="text-green-400 text-xs leading-relaxed">
                                  <code>{msg.codePreview.code}</code>
                                </pre>
                              </div>
                            ) : (
                              <div className="text-center text-gray-400 text-sm py-2">
                                <div className="flex items-center justify-center gap-2">
                                  <Code size={16} />
                                </div>
                              </div>
                            )}
                          </div>
                          
                          {/* Changes in plain English */}
                          <div className="text-gray-300 text-sm mb-3">
                            <strong>Changes:</strong> {msg.codePreview.changes}
                          </div>
                          
                          {showApproval && messages.indexOf(msg) === messages.length - 1 && (
                            <div className="flex gap-3 mt-4">
                              <button 
                                onClick={() => {
                                  setShowApproval(false);
                                  setMessages(m => [...m, { sender: "agent", text: "Perfect! I'll implement these changes now. This will take about 30 seconds..." }]);
                                  setTimeout(() => {
                                    setMessages(m => [...m, { sender: "agent", text: "✅ Done! I've successfully implemented the dark mode feature. The theme context has been created and is ready to use. Would you like me to add the toggle button to your navigation?" }]);
                                  }, 2000);
                                }}
                                className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg text-sm font-medium transition-colors"
                              >
                                Approve & Implement
                              </button>
                              <button 
                                onClick={() => {
                                  setShowApproval(false);
                                  setMessages(m => [...m, { sender: "agent", text: "No problem! Let me know if you'd like me to modify the approach or try something different." }]);
                                }}
                                className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg text-sm font-medium transition-colors"
                              >
                                Cancel
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}
                
                {/* Regular message text */}
                <div className={msg.fileAnalysis || msg.taskPlan || msg.codePreview ? "mt-2" : ""}>
                  {msg.text}
                </div>
              </div>

              {msg.file && (
                <div className="mt-2 p-2 bg-gray-700 rounded-lg">
                  {msg.file.type.startsWith('image/') ? (
                    <img src={msg.file.url} alt={msg.file.name} className="max-w-full h-auto rounded" />
                  ) : msg.file.type.startsWith('video/') ? (
                    <video src={msg.file.url} controls className="max-w-full h-auto rounded" />
                  ) : (
                    <div className="flex items-center gap-2">
                      <Paperclip size={16} />
                      <span className="text-sm">{msg.file.name}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
        {currentStatus && (
          <div className="flex w-full mb-3 sm:mb-4 justify-start">
            <div className="text-white px-3 sm:px-4 py-2 sm:py-3 max-w-[85%] sm:max-w-2xl lg:max-w-4xl break-words">
              <div className="flex items-center gap-2">
                <div className={`w-1.5 h-1.5 rounded-full animate-pulse ${
                  currentStatus === "Analyzing Repository" ? "bg-blue-400" :
                  currentStatus === "Reading Files" ? "bg-yellow-400" :
                  currentStatus === "Planning Task" ? "bg-orange-400" :
                  "bg-gray-400"
                }`}></div>
                <span className={`text-xs uppercase tracking-wide font-medium ${
                  currentStatus === "Analyzing Repository" ? "text-blue-400" :
                  currentStatus === "Reading Files" ? "text-yellow-400" :
                  currentStatus === "Planning Task" ? "text-orange-400" :
                  "text-gray-400"
                }`}>
                  {currentStatus}
                </span>
              </div>
            </div>
          </div>
        )}
        
        {/* Suggestions card */}
        {showSuggestions && (
          <div className="flex w-full mb-3 sm:mb-4 justify-start animate-fade-in">
            <div className="text-white px-3 sm:px-4 py-3 max-w-[85%] sm:max-w-2xl lg:max-w-4xl break-words">
              <div className="p-4 bg-gray-900/50 border border-gray-700 rounded-xl">
                <div className="flex items-center gap-2 text-blue-400 text-xs uppercase tracking-wide font-medium mb-3">
                  <div className="w-1.5 h-1.5 bg-blue-400 rounded-full"></div>
                  🔧 I can help you with
                </div>
                <div className="grid grid-cols-1 gap-2 text-sm">
                  <div className="text-gray-300">• "Fix the login bug in auth.js" → Analyzes your repo and patches the issue</div>
                  <div className="text-gray-300">• "Add dark mode" → Reads your components and implements theming</div>
                  <div className="text-gray-300">• "Make it mobile responsive" → Updates your CSS files intelligently</div>
                  <div className="text-gray-300">• "Deploy to production" → Connects to your hosting and deploys</div>
                  <div className="text-gray-300">• "Clean up this code" → Refactors while preserving functionality</div>
                </div>
                <div className="mt-3 text-xs text-gray-500">
                  First, connect your GitHub repository - then just chat normally!
                </div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
        
        {/* User reassurance footer */}
        <div className="text-center py-4 text-gray-500 text-xs">
          You see every step. You approve every move.<br />
          Nothing happens without your permission.
        </div>
      </div>
      
      <div className="fixed bottom-0 left-0 w-full bg-black border-t border-gray-800 safe-area-pb">
        <div className="max-w-6xl mx-auto p-3 sm:p-4">
          {/* File preview */}
          {selectedFile && (
            <div className="mb-3 p-3 bg-gray-900 rounded-2xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                {selectedFile.type.startsWith('image/') ? (
                  <Image size={20} className="text-blue-500" />
                ) : selectedFile.type.startsWith('video/') ? (
                  <Video size={20} className="text-blue-500" />
                ) : (
                  <Paperclip size={20} className="text-blue-500" />
                )}
                <span className="text-white text-sm truncate max-w-48">{selectedFile.name}</span>
              </div>
              <button 
                onClick={removeFile}
                className="text-gray-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>
          )}
          
          {/* ChatGPT-style Input area */}
          <div className="relative bg-gray-800/50 rounded-2xl border border-gray-600/50 focus-within:border-gray-500 transition-all duration-200 shadow-lg backdrop-blur-sm">
            <div className="flex items-end gap-3 p-4">
              {/* Upload dropdown button */}
              <div className="relative">
                <button
                  onClick={toggleUploadDropdown}
                  className="p-2 text-gray-400 hover:text-gray-300 transition-colors rounded-lg hover:bg-gray-700/50"
                >
                  <Paperclip size={18} />
                </button>
                
                <UploadDropdown
                  isOpen={showUploadDropdown}
                  connectedRepo={connectedRepo}
                  onConnectRepository={handleConnectRepository}
                  onUploadFiles={() => {
                    fileInputRef.current?.click();
                    setShowUploadDropdown(false);
                  }}
                />
              </div>
              
              {/* Text input */}
              <textarea
                ref={inputRef}
                value={input}
                onChange={handleInput}
                onKeyDown={handleKeyDown}
                placeholder="Connect your repository and describe what you need..."
                rows={1}
                className="resize-none bg-transparent text-white w-full px-0 py-2 text-sm focus:outline-none placeholder-gray-400 leading-5"
                style={{ minHeight: 20, maxHeight: 160 }}
              />
              
              {/* Send button */}
              <button 
                onClick={handleSend}
                disabled={!input.trim() && !selectedFile}
                className="p-2.5 bg-white hover:bg-gray-200 disabled:bg-gray-600 disabled:text-gray-400 text-black rounded-lg transition-all duration-200 shrink-0 disabled:cursor-not-allowed"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
          
          {/* Disclaimer */}
          <div className="mt-3 text-center">
            <p className="text-xs text-gray-400">
              Taskbolt can make mistakes. Always review changes before approval.
            </p>
          </div>
          
          {/* Hidden file input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,video/*"
            onChange={handleFileSelect}
            className="hidden"
          />
        </div>
      </div>

      {/* Repository Connection Modal */}
      <RepositoryModal
        isOpen={isRepoModalOpen}
        onClose={() => setIsRepoModalOpen(false)}
        onSelectRepository={handleSelectRepository}
      />
    </div>
  );
}