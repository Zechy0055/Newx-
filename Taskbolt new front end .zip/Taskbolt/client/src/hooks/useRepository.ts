import { useState, useEffect } from 'react';
import { Repository } from '@/types';

export function useRepository() {
  const [connectedRepo, setConnectedRepo] = useState<Repository | null>(() => {
    const saved = localStorage.getItem('connected-repository');
    return saved ? JSON.parse(saved) : null;
  });

  // Save to localStorage whenever repository changes
  useEffect(() => {
    if (connectedRepo) {
      localStorage.setItem('connected-repository', JSON.stringify(connectedRepo));
    } else {
      localStorage.removeItem('connected-repository');
    }
  }, [connectedRepo]);

  const connectRepository = (repo: Repository) => {
    setConnectedRepo(repo);
  };

  const disconnectRepository = () => {
    setConnectedRepo(null);
  };

  return {
    connectedRepo,
    connectRepository,
    disconnectRepository,
    isConnected: !!connectedRepo
  };
}