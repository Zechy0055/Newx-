import { useState, useRef, useEffect } from 'react';

export function useInputManager() {
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    setIsTyping(true);
    
    // Auto-resize textarea
    e.target.style.height = 'auto';
    e.target.style.height = Math.min(e.target.scrollHeight, 160) + 'px';
    
    // Hide typing indicator after user stops typing
    setTimeout(() => setIsTyping(false), 1000);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>, onSend: () => void) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  };

  const clearInput = () => {
    setInput("");
    setIsTyping(false);
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
    }
  };

  return {
    input,
    isTyping,
    inputRef,
    handleInput,
    handleKeyDown,
    clearInput,
    setInput,
    setIsTyping
  };
}