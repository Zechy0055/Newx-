import { useState, useEffect } from 'react';
import { Message } from '@/types';

export function useChat() {
  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem('taskbolt-messages');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [input, setInput] = useState("");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const [showWelcome, setShowWelcome] = useState(true);
  const [currentStatus, setCurrentStatus] = useState<string | null>(null);
  const [showApproval, setShowApproval] = useState(false);
  const [taskAccepted, setTaskAccepted] = useState(false);
  const [currentTaskId, setCurrentTaskId] = useState<string | null>(null);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [expandedCodeId, setExpandedCodeId] = useState<string | null>(null);

  // Save messages to localStorage
  useEffect(() => {
    localStorage.setItem('taskbolt-messages', JSON.stringify(messages));
  }, [messages]);

  // Welcome message effect
  useEffect(() => {
    if (showWelcome) {
      const timer = setTimeout(() => {
        setMessages([{ 
          sender: "agent", 
          text: "👋 Hey, I'm your AI coding agent. Connect your repository and I'll help you fix bugs, add features, and improve your code!" 
        }]);
        setShowWelcome(false);
        
        setTimeout(() => {
          setShowSuggestions(true);
        }, 3000);
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [showWelcome]);

  const addMessage = (message: Message) => {
    setMessages(prev => [...prev, message]);
  };

  const clearChat = () => {
    setMessages([]);
    setInput("");
    setSelectedFile(null);
    setShowSuggestions(false);
    setCurrentStatus(null);
    setShowApproval(false);
    setCurrentTaskId(null);
    setTaskAccepted(false);
  };

  const startCodingWorkflow = (userRequest: string) => {
    const taskId = Date.now().toString();
    setCurrentTaskId(taskId);
    
    // Phase 1: File Analysis
    setTimeout(() => {
      setCurrentStatus("Analyzing Repository");
    }, 500);
    
    setTimeout(() => {
      setCurrentStatus("Reading Files");
    }, 2000);
    
    setTimeout(() => {
      setCurrentStatus("Planning Task");
    }, 4000);
    
    setTimeout(() => {
      setCurrentStatus(null);
      
      // Add analysis results
      const analysisMessage: Message = {
        sender: "agent",
        text: "I've analyzed your repository structure. Here's what I found:",
        fileAnalysis: {
          files: [
            { name: "client/src/pages/dashboard.tsx", type: "React Component", lines: 650, issues: ["Complex component", "Could use refactoring"] },
            { name: "client/src/components/NavBar.tsx", type: "React Component", lines: 158 },
            { name: "server/routes.ts", type: "API Routes", lines: 45 },
            { name: "shared/schema.ts", type: "Database Schema", lines: 32 }
          ],
          summary: "Found React frontend with Express backend. Repository has good structure with client/server separation."
        }
      };
      
      addMessage(analysisMessage);
      
      // Phase 2: Task Planning
      setTimeout(() => {
        const planMessage: Message = {
          sender: "agent",
          text: "Based on your request, here's my implementation plan:",
          taskPlan: {
            title: userRequest.includes("dark mode") ? "Implement Dark Mode" : 
                   userRequest.includes("responsive") ? "Make Mobile Responsive" :
                   userRequest.includes("bug") ? "Fix Authentication Bug" : "Code Enhancement",
            steps: [
              { step: "Update theme context", files: ["client/src/lib/ThemeContext.tsx"], estimated: "2 min" },
              { step: "Modify main components", files: ["client/src/App.tsx", "client/src/pages/dashboard.tsx"], estimated: "3 min" },
              { step: "Update CSS variables", files: ["client/src/index.css"], estimated: "1 min" }
            ],
            dependencies: ["React", "Tailwind CSS"]
          }
        };
        
        addMessage(planMessage);
        
        // Phase 3: Show code preview
        setTimeout(() => {
          showCodePreview();
        }, 2000);
      }, 1500);
    }, 6000);
  };

  const showCodePreview = () => {
    const codeMessage: Message = {
      sender: "agent",
      text: "Here's the code I'll implement. Review and approve to proceed:",
      codePreview: {
        filename: "client/src/lib/ThemeContext.tsx",
        language: "typescript",
        code: `import { createContext, useContext, useState, useEffect } from 'react';

type Theme = 'light' | 'dark';

interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>('light');

  useEffect(() => {
    const stored = localStorage.getItem('theme') as Theme;
    if (stored) {
      setTheme(stored);
      document.documentElement.classList.toggle('dark', stored === 'dark');
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
};`,
        changes: "Creates new theme context with localStorage persistence and dark mode toggle functionality"
      }
    };
    
    addMessage(codeMessage);
    setShowApproval(true);
  };

  return {
    // State
    messages,
    input,
    selectedFile,
    isTyping,
    showWelcome,
    currentStatus,
    showApproval,
    taskAccepted,
    currentTaskId,
    showSuggestions,
    expandedCodeId,
    
    // Setters
    setInput,
    setSelectedFile,
    setIsTyping,
    setShowApproval,
    setTaskAccepted,
    setCurrentTaskId,
    setShowSuggestions,
    setExpandedCodeId,
    setCurrentStatus,
    
    // Actions
    addMessage,
    clearChat,
    startCodingWorkflow,
    showCodePreview
  };
}