import { useState, useRef } from 'react';

export function useFileUpload() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [showUploadDropdown, setShowUploadDropdown] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const removeFile = () => {
    setSelectedFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
    setShowUploadDropdown(false);
  };

  const toggleUploadDropdown = () => {
    setShowUploadDropdown(!showUploadDropdown);
  };

  return {
    selectedFile,
    showUploadDropdown,
    fileInputRef,
    handleFileSelect,
    removeFile,
    triggerFileInput,
    toggleUploadDropdown,
    setShowUploadDropdown
  };
}